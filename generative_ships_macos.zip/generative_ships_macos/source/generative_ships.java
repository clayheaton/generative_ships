import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.Random; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class generative_ships extends PApplet {



// Good UI library for Processing
// https://github.com/sojamo/controlp5/tree/master/examples/controllers


boolean debug = true;

static int UI_PANEL_WIDTH = 255;
static int GRID_OUTER_MARGIN = 20;
static int GRID_INNER_MARGIN = 20;

static float SCALE_MIN = 0;
static float SCALE_MAX = 1.0f;

static float SHEAR_MIN = 0;
static float SHEAR_MAX = 10.0f;

static float ROTATION_MIN = 0;
static float ROTATION_MAX = TWO_PI;

static int MIN_COLOR = 0;
static int MAX_COLOR = 255;

/*
Background Color
 */
CheckBox bgCheckbox;
boolean dark_background = false;
int bg_dark = color(15, 40, 61);
int bg_white = color(255);


/*
FLAIR
 */
static int FLAIR_MIN_DIM = 0;
static int FLAIR_MAX_DIM = 100;
static float FLAIR_SHEAR_MIN = 0;
static float FLAIR_SHEAR_MAX = 1.0f;

Range flairWidthRange, flairHeightRange, flairRotationRange, flairShearRange;
int flair_minWidth, flair_maxWidth;
int flair_minHeight, flair_maxHeight;
float flair_minRotation, flair_maxRotation;
float flair_minShear, flair_maxShear;

Range flairRedRange, flairGreenRange, flairBlueRange;
int flair_minRed, flair_maxRed;
int flair_minGreen, flair_maxGreen;
int flair_minBlue, flair_maxBlue;
/*
END FLAIR
 */

/*
COCKPITS
 */
static int COCKPIT_MIN_WIDTH = 50;
static int COCKPIT_MAX_WIDTH = 200;
static int COCKPIT_MIN_HEIGHT = 50;
static int COCKPIT_MAX_HEIGHT = 250;
static int COCKPIT_MIN_BAYS = 0;
static int COCKPIT_MAX_BAYS = 4;

Range cockpitWidthRange, cockpitHeightRange, cockpitBaysRange;
CheckBox cockpitCheckbox;
int cockpit_minWidth, cockpit_maxWidth;
int cockpit_minHeight, cockpit_maxHeight;
int cockpit_minBays, cockpit_maxBays;
boolean cockpit_window1, cockpit_window2;
boolean cockpit_type1, cockpit_type2, cockpit_type3;

Range cockpitRedRange, cockpitGreenRange, cockpitBlueRange;
int cockpit_minRed, cockpit_maxRed;
int cockpit_minGreen, cockpit_maxGreen;
int cockpit_minBlue, cockpit_maxBlue;

/*
END COCKPITS
 */

/*
WINGS
 */
static int WINGS_MIN_WIDTH = 20;
static int WINGS_MAX_WIDTH = 150;
static int WINGS_MIN_HEIGHT = 150;
static int WINGS_MAX_HEIGHT = 300;

Range wingsRedRange, wingsGreenRange, wingsBlueRange;
int wings_minRed, wings_maxRed;
int wings_minGreen, wings_maxGreen;
int wings_minBlue, wings_maxBlue;

Range wingsWidthTopRange, wingsWidthBottomRange, wingsHeightRange, wingsShearRange, wingsRotationRange;
int wings_minWidthTop, wings_maxWidthTop;
int wings_minWidthBottom, wings_maxWidthBottom;
int wings_minHeight, wings_maxHeight;
float wings_minShear, wings_maxShear;
float wings_minRotation, wings_maxRotation;

/*
END WINGS
 */

/*
SEGMENTS
 */
static int SEGMENTS_MIN_WIDTH = 50;
static int SEGMENTS_MAX_WIDTH = 200;
static int SEGMENTS_MIN_HEIGHT = 150;
static int SEGMENTS_MAX_HEIGHT = 250;
static int SEGMENTS_MIN_CORNER_RADIUS = 0;
static int SEGMENTS_MAX_CORNER_RADIUS = 100;
static int SEGMENTS_MIN_SIDE = 0;
static int SEGMENTS_MAX_SIDE = 4;

Range segmentsRedRange, segmentsGreenRange, segmentsBlueRange;
int segments_minRed, segments_maxRed;
int segments_minGreen, segments_maxGreen;
int segments_minBlue, segments_maxBlue;

Range segmentsWidthRange, segmentsHeightRange;
int segments_minWidth, segments_maxWidth;
int segments_minHeight, segments_maxHeight;

Range segmentsCornerTopRange, segmentsCornerBottomRange;
int segments_minCornerTop, segments_maxCornerTop;
int segments_minCornerBottom, segments_maxCornerBottom;

Range segmentsStripeRedRange, segmentsStripeGreenRange, segmentsStripeBlueRange, segmentsStripeSideRange;
int segments_minStripeRed, segments_maxStripeRed;
int segments_minStripeGreen, segments_maxStripeGreen;
int segments_minStripeBlue, segments_maxStripeBlue;
int segments_minStripeSide, segments_maxStripeSide;
/*
END SEGMENTS
 */

/*
TAILS
 */
static int TAILS_MIN_WIDTH = 40;
static int TAILS_MAX_WIDTH = 150;
static int TAILS_MIN_HEIGHT = 100;
static int TAILS_MAX_HEIGHT = 200;
static int TAILS_MIN_ENGINES = 1;
static int TAILS_MAX_ENGINES = 4;

Range tailsRedRange, tailsGreenRange, tailsBlueRange;
int tails_minRed, tails_maxRed;
int tails_minGreen, tails_maxGreen;
int tails_minBlue, tails_maxBlue;

Range tailsWidthRange, tailsHeightRange;
int tails_minWidth, tails_maxWidth;
int tails_minHeight, tails_maxHeight;

Range tailsEnginesRange;
int tails_minEngines, tails_maxEngines;
/*
END TAILS
 */



/*
 SHIPS
 */
static int SHIPS_MIN_SEGMENTS = 0;
static int SHIPS_MAX_SEGMENTS = 6;
static float SHIPS_MIN_AMPLITUDE = 0;
static float SHIPS_MAX_AMPLITUDE = 1;
static int SHIPS_MIN_WINGS = 0;
static int SHIPS_MAX_WINGS = 4;
static boolean SHIPS_WINGS_TOP = true;
static boolean SHIPS_WINGS_BOTTOM = true;

Range shipsSegmentsRange, shipsAmplitudeRange, shipsWingsRange;
int ships_minSegments, ships_maxSegments;
float ships_minAmplitude, ships_maxAmplitude;
int ships_minWings, ships_maxWings;

CheckBox shipsWingPositions;
boolean ships_wingsTop, ships_wingsBottom;
/*
 END SHIPS
 */


/*
ARMADAS
 */
static float ARMADAS_MIN_SCALE = 0.5f;
static float ARMADAS_MAX_SCALE = 1.5f;
Range armadasScaleRange;
float armadas_minScale, armadas_maxScale;
/*
END ARMADAS
 */


ControlP5 cp5;
Grid activeGrid, flairGrid, cockpitGrid, wingsGrid, segmentsGrid, tailsGrid, shipsGrid, armadasGrid;
ArrayList<Grid> grids;

public void setup() {
   

  grids = new ArrayList<Grid>();

  // Set up the Grids
  flairGrid = new FlairGrid(5, 3, "flair");  
  activeGrid = flairGrid;

  cockpitGrid = new CockpitGrid(3, 2, "cockpit");
  wingsGrid = new WingGrid(3, 1, "wings");
  segmentsGrid = new SegmentGrid(4, 2, "segments");
  tailsGrid = new TailGrid(3, 2, "tails");
  shipsGrid = new ShipGrid(1, 1, "ships");
  armadasGrid = new ArmadaGrid(4, 2, "armadas");

  grids.add(flairGrid);
  grids.add(cockpitGrid);
  grids.add(wingsGrid);
  grids.add(segmentsGrid);
  grids.add(tailsGrid);
  grids.add(shipsGrid);
  grids.add(armadasGrid);

  setupControls();

  for (Grid g : grids) {
    g.rebuild();
  }

  if (dark_background) {
    background(bg_dark);
  } else {
    background(bg_white);
  }
}

public void draw() {
  if (dark_background) {
    background(bg_dark);
  } else {
    background(bg_white);
  }

  drawUIPanel();
  activeGrid.display();
}

public void drawUIPanel() {
  noStroke();
  fill(128);
  rect(0, 0, UI_PANEL_WIDTH, height);
}



/*
CONTROLS
 */

public void switchTabs(ControlEvent theControlEvent) {
  String tabName = theControlEvent.getTab().getName();
  println("Clicked " + tabName);

  if (tabName == "default") {
    activeGrid = flairGrid;
  } else if (tabName == "cockpits") {
    activeGrid = cockpitGrid;
  } else if (tabName == "wings") {
    activeGrid = wingsGrid;
  } else if (tabName == "segments") {
    activeGrid = segmentsGrid;
  } else if (tabName == "tails") {
    activeGrid = tailsGrid;
  } else if (tabName == "ships") {
    activeGrid = shipsGrid;
  } else if (tabName == "armadas") {
    activeGrid = armadasGrid;
  }
}

public void controlEvent(ControlEvent theControlEvent) {
  if (theControlEvent.isTab()) {
    switchTabs(theControlEvent);
    return;
  }
  activeGrid.handleEvents(theControlEvent);
}

public void setupControls() {
  cp5 = new ControlP5(this);
  cp5.getTab("default").activateEvent(true).setLabel("flair").setId(1);
  cp5.addTab("cockpits").activateEvent(true).setId(2);
  cp5.addTab("wings").activateEvent(true).setId(3);
  cp5.addTab("segments").activateEvent(true).setId(4);
  cp5.addTab("tails").activateEvent(true).setId(5);
  cp5.addTab("ships").activateEvent(true).setId(6);
  cp5.addTab("armadas").activateEvent(true).setId(7);

  // Button to trigger redrawing of components
  cp5.addButton("rebuild")
    .setBroadcast(false)
    .setValue(0)
    .setPosition(10 + UI_PANEL_WIDTH/2, height-40)
    .setSize(UI_PANEL_WIDTH/2 - 20, 30)
    .moveTo("global")
    .setBroadcast(true);

  // Button to reset components
  int c1 = color(240, 26, 16);
  int c2 = color(255, 0, 0);
  cp5.addButton("reset")
    .setBroadcast(false)
    .setValue(0)
    .setColorBackground(c1)
    .setColorForeground(c2)
    .setPosition(10, height-40)
    .setSize(UI_PANEL_WIDTH/2 - 20, 30)
    .moveTo("global")
    .setBroadcast(true);

  cp5.addButton("bgColor")
    .setBroadcast(false)
    .setValue(0)
    .setColorBackground(color(50))
    .setColorForeground(color(255))
    .setPosition(10, height - 80)
    .setSize(UI_PANEL_WIDTH/2 - 20, 30)
    .moveTo("global")
    .setBroadcast(true);

  flairGrid.createUIComponents();
  cockpitGrid.createUIComponents();
  wingsGrid.createUIComponents();
  segmentsGrid.createUIComponents();
  tailsGrid.createUIComponents();
  shipsGrid.createUIComponents();
  armadasGrid.createUIComponents();
}

// Functions called by controlp5 buttons
public void bgColor(int theValue) {
  dark_background = !dark_background;
}

public void rebuild(int theValue) {
  activeGrid.rebuild();
}

public void reset(int theValue) {
  activeGrid.setRangeValues();
  activeGrid.rebuild();
}
class Armada {
  Ship ship;
  float sectorWidth, sectorHeight, scalefactor;
  Armada(float _sectorWidth, float _sectorHeight) {
    this.ship = new Ship();
    this.sectorWidth = _sectorWidth;
    this.sectorHeight = _sectorHeight;
    float scalefactorW = this.sectorWidth / this.ship.shipLength;
    float scalefactorH = this.sectorHeight / this.ship.shipHeight;
    this.scalefactor = min(1,this.scalefactor = min(scalefactorW,scalefactorH));
  }

  public void display() {
    pushMatrix();
    scale(this.scalefactor);
    this.ship.display();
    popMatrix();
  }
}






class ArmadaSector extends Sector {
  Armada armada;
  ArmadaSector(int _x, int _y, PVector _corner, int _w, int _h) {
    super(_x, _y, _corner, _w, _h);
    rebuild();
  }
  public void rebuild() {
    armada = new Armada(this.w, this.h);
  }

  public void display() {
    if (debug) {
      debugDisplay();
    }

    pushMatrix();
    translate(this.center.x, this.center.y);
    this.armada.display();
    popMatrix();
  }
}




class ArmadaGrid extends Grid {
  ArmadaGrid(int _nx, int _ny, String _sectorType) {
    super(_nx, _ny, _sectorType);
    setRangeValues();
  }

  public void createUIComponents() {

  }

  public void setRangeValues() {

  }

  public void handleEvents(ControlEvent theControlEvent) {

  }

  public void makeSectors() {
    int sectorW = (int)(width - UI_PANEL_WIDTH - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsAcross - 1))) / this.sectorsAcross;
    int sectorH = (int)(height - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsDown - 1))) / sectorsDown;

    for (int y = 0; y < sectorsDown; y++) {
      for (int x = 0; x < sectorsAcross; x++) {
        PVector secCorner = new PVector(x*sectorW + GRID_OUTER_MARGIN + (x * GRID_INNER_MARGIN) + UI_PANEL_WIDTH, y*sectorH + GRID_OUTER_MARGIN + (y * GRID_INNER_MARGIN));
        Sector s = null;
        s = new ArmadaSector(x, y, secCorner, sectorW, sectorH);
        if (null != s) {
          sectors[x][y] = s;
        }
      }
    }
  }
}
class Cockpit {
  int w, h, r, g, b, bays;
  float window_diam;
  String cockpit_type, cockpit_window_style;
  int fillcolor, outlinecolor;
  Cockpit() {
    this.w = (int)random(cockpit_minWidth, cockpit_maxWidth);
    this.h = (int)random(cockpit_minHeight, cockpit_maxHeight);
    this.r = (int)random(cockpit_minRed, cockpit_maxRed);
    this.g = (int)random(cockpit_minGreen, cockpit_maxGreen);
    this.b = (int)random(cockpit_minBlue, cockpit_maxBlue);
    this.bays = (int)random(cockpit_minBays, cockpit_maxBays+0.99f); // bump because otherwise we never see 4
    this.fillcolor = color(this.r, this.g, this.b);
    int black = color(0);
    this.outlinecolor = lerpColor(this.fillcolor, black, 0.33f);

    if (this.bays == 0) {
      this.window_diam = 0;
    } else {
      if (this.w > this.h) {
        this.window_diam = (this.h / this.bays) * 0.7f;
      } else {
        this.window_diam = (this.w / this.bays) * 0.7f;
      }
    }

    ArrayList<String> types = new ArrayList<String>();
    if (cockpit_type1) types.add("type1");
    if (cockpit_type2) types.add("type2");
    if (cockpit_type3) types.add("type3");

    // Must always have one type
    if (types.size() == 0) types.add("type1");

    // Pick a random type from the list
    cockpit_type = types.get(new Random().nextInt(types.size()));

    ArrayList<String> windows = new ArrayList<String>();
    if (cockpit_window1) windows.add("window1");
    if (cockpit_window2) windows.add("window2");

    if (windows.size() == 0) windows.add("window1");

    cockpit_window_style = windows.get(new Random().nextInt(windows.size()));
  }

  public void display() {
    ellipseMode(CENTER);
    rectMode(CENTER);
    if (cockpit_type == "type1") { 
      drawType1();
    } else if (cockpit_type == "type2") { 
      drawType2();
    } else if (cockpit_type == "type3") { 
      drawType3();
    }
    rectMode(CORNER);
  }

  public void drawType1() {
    noStroke();
    fill(220, 220, 255);
    float radius = this.window_diam/2;

    // Square with a circle coming out the front
    for (int i = 0; i < this.bays; i++) {
      float yCenter = (this.bays * radius) - radius - (i*this.window_diam);
      if (cockpit_window_style == "window1") {
        ellipse(-this.w/2, yCenter, this.window_diam, this.window_diam*1.2f);
      } else {
        // Square windows
        rect(-this.w/2, yCenter, this.window_diam*0.9f, this.window_diam*0.9f);
      }
    }


    // hull
    rectMode(CORNER);
    stroke(this.outlinecolor);
    strokeWeight(1);
    fill(this.fillcolor);
    rect(-this.w/2, -this.h/2, this.w, this.h);
  }

  public void drawType2() {
    // Elongated arc
    noStroke();
    fill(220, 220, 255);
    float radius = this.window_diam/2;

    for (int i = 0; i < this.bays; i++) {
      float yCenter = (this.bays * radius) - radius - (i*this.window_diam);
      if (cockpit_window_style == "window1") {
        ellipse(-this.w/2, yCenter, this.window_diam, this.window_diam);
      } else {
        // Square windows
        rect(-this.w/2, yCenter, this.window_diam*0.9f, this.window_diam*0.9f);
      }
    }


    stroke(this.outlinecolor);
    strokeWeight(1);
    fill(this.fillcolor);
    arc(0, 0, this.w, this.h, HALF_PI, 3*PI/2, CHORD);
  }

  public void drawType3() {
    // Triangle
    noStroke();
    fill(220, 220, 255);
    ArrayList<PVector> points = new ArrayList<PVector>();

    PVector tip = new PVector(-this.w/2, 0);
    PVector top = new PVector(this.w/2, -this.h/2);
    PVector bottom = new PVector(this.w/2, this.h/2);

    points.add(PVector.lerp(tip, top, 0.33f));
    points.add(PVector.lerp(tip, top, 0.66f));
    points.add(PVector.lerp(tip, bottom, 0.33f));
    points.add(PVector.lerp(tip, bottom, 0.66f));

    if (this.bays > 0) {
      if (this.w > this.h) {
        this.window_diam = (this.h / max(1.4f, this.bays)) * 0.7f;
      } else {
        this.window_diam = (this.w / max(1.4f, this.bays)) * 0.7f;
      }
    }

    for (int i = 0; i < this.bays; i++) {
      PVector pt = points.get(i);
      if (cockpit_window_style == "window1") {
        ellipse(pt.x, pt.y, this.window_diam, this.window_diam);
      } else {
        // Square windows
        rect(pt.x, pt.y, this.window_diam, this.window_diam);
      }
    }

    stroke(this.outlinecolor);
    strokeWeight(1);
    fill(this.fillcolor);
    triangle(-this.w/2, 0, this.w/2, -this.h/2, this.w/2, this.h/2);
  }
}


class CockpitSector extends Sector {
  Cockpit cockpit;
  CockpitSector(int _x, int _y, PVector _corner, int _w, int _h) {
    super(_x, _y, _corner, _w, _h);
    rebuild();
  }

  public void rebuild() {
    cockpit = new Cockpit();
  }

  public void display() {
    if (debug) {
      debugDisplay();
    }

    pushMatrix();
    translate(this.center.x, this.center.y);
    this.cockpit.display();
    popMatrix();
  }
}


class CockpitGrid extends Grid {
  CockpitGrid(int _nx, int _ny, String _sectorType) {
    super(_nx, _ny, _sectorType);
    setRangeValues();
  }
  public void createUIComponents() {
    cockpitWidthRange = cp5.addRange("cockpit width")
      // disable broadcasting since setRange and setRangeValues will trigger an event
      .setBroadcast(false) 
      .setPosition(10, 30)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(COCKPIT_MIN_WIDTH, COCKPIT_MAX_WIDTH)
      .setRangeValues(COCKPIT_MIN_WIDTH, COCKPIT_MAX_WIDTH)
      .moveTo("cockpits")
      .setBroadcast(true);

    cockpitHeightRange = cp5.addRange("cockpit height")
      .setBroadcast(false) 
      .setPosition(10, 70)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(COCKPIT_MIN_HEIGHT, COCKPIT_MAX_HEIGHT)
      .setRangeValues(COCKPIT_MIN_HEIGHT, COCKPIT_MAX_HEIGHT)
      .moveTo("cockpits")
      .setBroadcast(true);

    cockpitBaysRange = cp5.addRange("cockpit bays")
      .setBroadcast(false) 
      .setPosition(10, 110)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(COCKPIT_MIN_BAYS, COCKPIT_MAX_BAYS)
      .setRangeValues(COCKPIT_MIN_BAYS, COCKPIT_MAX_BAYS)
      .moveTo("cockpits")
      .setBroadcast(true);

    cockpitRedRange = cp5.addRange("cockpit red")
      .setBroadcast(false) 
      .setPosition(10, 150)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("cockpits")
      .setBroadcast(true);

    cockpitGreenRange = cp5.addRange("cockpit green")
      .setBroadcast(false) 
      .setPosition(10, 190)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("cockpits")
      .setBroadcast(true);

    cockpitBlueRange = cp5.addRange("cockpit blue")
      .setBroadcast(false) 
      .setPosition(10, 230)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("cockpits")
      .setBroadcast(true);

    cockpitCheckbox = cp5.addCheckBox("cockpit checkBox")
      .setPosition(10, 300)
      .setSize(30, 30)
      .setItemsPerRow(3)
      .setSpacingColumn(50)
      .setSpacingRow(20)
      .addItem("type 1", 1)
      .addItem("type 2", 2)
      .addItem("type 3", 3)
      .addItem("window 1", 4)
      .addItem("window 2", 5)
      .moveTo("cockpits")
      .toggle(0)
      .toggle(1)
      .toggle(2)
      .toggle(3)
      .toggle(4)
      ;
  }

  public void setRangeValues() {
    cockpit_minWidth = COCKPIT_MIN_WIDTH;
    cockpit_maxWidth = COCKPIT_MAX_WIDTH;
    cockpit_minHeight = COCKPIT_MIN_HEIGHT;
    cockpit_maxHeight = COCKPIT_MAX_HEIGHT;
    cockpit_minBays = COCKPIT_MIN_BAYS;
    cockpit_maxBays = COCKPIT_MAX_BAYS;
    cockpit_window1 = true;
    cockpit_window2 = true;
    cockpit_type1 = true;
    cockpit_type2 = true;
    cockpit_type3 = true;
    cockpit_minRed = MIN_COLOR;
    cockpit_maxRed = MAX_COLOR;
    cockpit_minGreen = MIN_COLOR;
    cockpit_maxGreen = MAX_COLOR;
    cockpit_minBlue = MIN_COLOR;
    cockpit_maxBlue = MAX_COLOR;

    try {
      cockpitWidthRange.setRangeValues(cockpit_minWidth, cockpit_maxWidth);
      cockpitHeightRange.setRangeValues(cockpit_minHeight, cockpit_maxHeight);
      cockpitBaysRange.setRangeValues(cockpit_minBays, cockpit_maxBays);
      cockpitRedRange.setRangeValues(cockpit_minRed, cockpit_maxRed);
      cockpitGreenRange.setRangeValues(cockpit_minGreen, cockpit_maxGreen);
      cockpitBlueRange.setRangeValues(cockpit_minBlue, cockpit_maxBlue);

      float[] v = {1, 1, 1, 1, 1};
      cockpitCheckbox.setArrayValue(v);
    }
    catch(NullPointerException e) {
    }
    finally {
    }
  }

  public void handleEvents(ControlEvent theControlEvent) {
    if (theControlEvent.isFrom(cockpitRedRange)) {
      cockpit_minRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      cockpit_maxRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("cockpit_minRed, cockpit_maxRed: " + cockpit_minRed + ", " + cockpit_maxRed);
    }

    if (theControlEvent.isFrom(cockpitGreenRange)) {
      cockpit_minGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      cockpit_maxGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("cockpit_minGreen, cockpit_maxGreen: " + cockpit_minGreen + ", " + cockpit_maxGreen);
    }

    if (theControlEvent.isFrom(cockpitBlueRange)) {
      cockpit_minBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      cockpit_maxBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("cockpit_minBlue, cockpit_maxBlue: " + cockpit_minBlue + ", " + cockpit_maxBlue);
    }

    if (theControlEvent.isFrom(cockpitWidthRange)) {
      cockpit_minWidth = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      cockpit_maxWidth = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("cockpit_minWidth, cockpit_maxWidth: " + cockpit_minWidth + ", " + cockpit_maxWidth);
    }  

    if (theControlEvent.isFrom(cockpitHeightRange)) {
      cockpit_minHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      cockpit_maxHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("cockpit_minHeight, cockpit_maxHeight: " + cockpit_minHeight + ", " + cockpit_maxHeight);
    }  

    if (theControlEvent.isFrom(cockpitBaysRange)) {
      cockpit_minBays = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      cockpit_maxBays = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("cockpit_minBays, cockpit_maxBays: " + cockpit_minBays + ", " + cockpit_maxBays);
    }  

    if (theControlEvent.isFrom(cockpitCheckbox)) {
      cockpit_type1 = PApplet.parseInt(cockpitCheckbox.getArrayValue()[0]) == 1 ? true : false;
      cockpit_type2 = PApplet.parseInt(cockpitCheckbox.getArrayValue()[1]) == 1 ? true : false;
      cockpit_type3 = PApplet.parseInt(cockpitCheckbox.getArrayValue()[2]) == 1 ? true : false;
      cockpit_window1 = PApplet.parseInt(cockpitCheckbox.getArrayValue()[3]) == 1 ? true : false;
      cockpit_window2 = PApplet.parseInt(cockpitCheckbox.getArrayValue()[4]) == 1 ? true : false;
      println("cockpitCheckbox: ");
      println(cockpitCheckbox.getArrayValue());
    }
  }

  public void makeSectors() {
    int sectorW = (int)(width - UI_PANEL_WIDTH - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsAcross - 1))) / this.sectorsAcross;
    int sectorH = (int)(height - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsDown - 1))) / sectorsDown;

    for (int y = 0; y < sectorsDown; y++) {
      for (int x = 0; x < sectorsAcross; x++) {
        PVector secCorner = new PVector(x*sectorW + GRID_OUTER_MARGIN + (x * GRID_INNER_MARGIN) + UI_PANEL_WIDTH, y*sectorH + GRID_OUTER_MARGIN + (y * GRID_INNER_MARGIN));
        Sector s = null;
        s = new CockpitSector(x, y, secCorner, sectorW, sectorH);
        if (null != s) {
          sectors[x][y] = s;
        }
      }
    }
  }
}
class Flair {
  int w, h, r, g, b;
  float shear, rot;
  PVector upperLeft, upperRight, lowerRight, lowerLeft;
  int mainColor;

  Flair() {
    this.w = (int)random(flair_minWidth, flair_maxWidth);
    this.h = (int)random(flair_minHeight, flair_maxHeight);
    this.r = (int)random(flair_minRed, flair_maxRed);
    this.g = (int)random(flair_minGreen, flair_maxGreen);
    this.b = (int)random(flair_minBlue, flair_maxBlue);
    this.rot = random(flair_minRotation, flair_maxRotation);
    this.shear = random(flair_minShear, flair_maxShear);

    this.mainColor = color(this.r, this.g, this.b);

    float offset = this.shear * this.w / 2;

    upperLeft = new PVector(0 - this.w/2 + offset, 0 - this.h/2);
    upperRight = new PVector(this.w/2 + offset, 0 - this.h/2);
    lowerRight = new PVector(this.w/2, this.h/2);
    lowerLeft = new PVector(0 - this.w/2, this.h/2);
  }

  public void display() {
    fill(this.r, this.g, this.b);
    noStroke();
    pushMatrix();
    rotate(this.rot);
    beginShape();
    vertex(upperLeft.x, upperLeft.y);
    vertex(upperRight.x, upperRight.y);
    vertex(lowerRight.x, lowerRight.y);
    vertex(lowerLeft.x, lowerLeft.y);
    endShape(CLOSE);
    popMatrix();
  }
  
  // For when drawing on a wing that is on the bottom of a ship
  public void displayReverse() {
    fill(this.r, this.g, this.b);
    noStroke();
    pushMatrix();
    rotate(-this.rot);
    beginShape();
    vertex(upperLeft.x, upperLeft.y);
    vertex(upperRight.x, upperRight.y);
    vertex(lowerRight.x, lowerRight.y);
    vertex(lowerLeft.x, lowerLeft.y);
    endShape(CLOSE);
    popMatrix();
  }
}


class FlairSector extends Sector {
  Flair flair;
  FlairSector(int _x, int _y, PVector _corner, int _w, int _h) {
    super(_x, _y, _corner, _w, _h);
    rebuild();
  }

  public void rebuild() {
    flair = new Flair();
  }

  public void display() {
    if (debug) {
      debugDisplay();
    }

    pushMatrix();
    translate(this.center.x, this.center.y);
    this.flair.display();
    popMatrix();
  }
}

class FlairGrid extends Grid {
  FlairGrid(int _nx, int _ny, String _sectorType) {
    super(_nx, _ny, _sectorType);
    setRangeValues();
  }
  public void createUIComponents() {
    flairWidthRange = cp5.addRange("flair width")
      // disable broadcasting since setRange and setRangeValues will trigger an event
      .setBroadcast(false) 
      .setPosition(10, 30)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(FLAIR_MIN_DIM, FLAIR_MAX_DIM)
      .setRangeValues(FLAIR_MIN_DIM, FLAIR_MAX_DIM)
      .moveTo("default")
      .setBroadcast(true);

    flairHeightRange = cp5.addRange("flair height")
      .setBroadcast(false) 
      .setPosition(10, 70)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(FLAIR_MIN_DIM, FLAIR_MAX_DIM)
      .setRangeValues(FLAIR_MIN_DIM, FLAIR_MAX_DIM)
      .moveTo("default")
      .setBroadcast(true);

    flairRotationRange = cp5.addRange("flair rotation")
      .setBroadcast(false) 
      .setPosition(10, 110)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(ROTATION_MIN, ROTATION_MAX)
      .setRangeValues(0, 0)
      .moveTo("default")
      .setBroadcast(true);

    flairShearRange = cp5.addRange("flair shear")
      .setBroadcast(false) 
      .setPosition(10, 150)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(FLAIR_SHEAR_MIN, FLAIR_SHEAR_MAX)
      .setRangeValues(0, 0)
      .moveTo("default")
      .setBroadcast(true);

    flairRedRange = cp5.addRange("flair red")
      .setBroadcast(false) 
      .setPosition(10, 190)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("default")
      .setBroadcast(true);

    flairGreenRange = cp5.addRange("flair green")
      .setBroadcast(false) 
      .setPosition(10, 230)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("default")
      .setBroadcast(true);

    flairBlueRange = cp5.addRange("flair blue")
      .setBroadcast(false) 
      .setPosition(10, 270)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("default")
      .setBroadcast(true);
  }

  public void setRangeValues() {
    flair_minWidth  = FLAIR_MIN_DIM;
    flair_maxWidth  = FLAIR_MAX_DIM;
    flair_minHeight = FLAIR_MIN_DIM;
    flair_maxHeight = FLAIR_MAX_DIM;
    flair_minRotation = 0;
    flair_maxRotation = 0;
    flair_minShear = 0;
    flair_maxShear = 0;
    flair_minRed = MIN_COLOR;
    flair_maxRed = MAX_COLOR;
    flair_minGreen = MIN_COLOR;
    flair_maxGreen = MAX_COLOR;
    flair_minBlue = MIN_COLOR;
    flair_maxBlue = MAX_COLOR;

    try {
      flairWidthRange.setRangeValues(flair_minWidth, flair_maxWidth);
      flairHeightRange.setRangeValues(flair_minHeight, flair_maxHeight);
      flairRotationRange.setRangeValues(flair_minRotation, flair_maxRotation);
      flairShearRange.setRangeValues(flair_minShear, flair_maxShear);
      flairRedRange.setRangeValues(flair_minRed, flair_maxRed);
      flairGreenRange.setRangeValues(flair_minGreen, flair_maxGreen);
      flairBlueRange.setRangeValues(flair_minBlue, flair_maxBlue);
    }
    catch(NullPointerException e) {
    }
    finally {
    }
  }

  public void handleEvents(ControlEvent theControlEvent) {
    if (theControlEvent.isFrom(flairWidthRange)) {
      // min and max values are stored in an array.
      // access this array with controller().arrayValue().
      // min is at index 0, max is at index 1.
      flair_minWidth = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      flair_maxWidth = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("flair_minWidth, flair_maxWidth: " + flair_minWidth + ", " + flair_maxWidth);
    }

    if (theControlEvent.isFrom(flairHeightRange)) {
      flair_minHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      flair_maxHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("flair_minHeight, flair_maxHeight: " + flair_minHeight + ", " + flair_maxHeight);
    }

    if (theControlEvent.isFrom(flairRotationRange)) {
      flair_minRotation = theControlEvent.getController().getArrayValue(0);
      flair_maxRotation = theControlEvent.getController().getArrayValue(1);
      println("flair_minRotation, flair_maxRotation: " + flair_minRotation + ", " + flair_maxRotation);
    }

    if (theControlEvent.isFrom(flairShearRange)) {
      flair_minShear = theControlEvent.getController().getArrayValue(0);
      flair_maxShear = theControlEvent.getController().getArrayValue(1);
      println("flair_minShear, flair_maxShear: " + flair_minShear + ", " + flair_maxShear);
    }


    if (theControlEvent.isFrom(flairRedRange)) {
      flair_minRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      flair_maxRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("flair_minRed, flair_maxRed: " + flair_minRed + ", " + flair_maxRed);
    }

    if (theControlEvent.isFrom(flairGreenRange)) {
      flair_minGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      flair_maxGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("flair_minGreen, flair_maxGreen: " + flair_minGreen + ", " + flair_maxGreen);
    }

    if (theControlEvent.isFrom(flairBlueRange)) {
      flair_minBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      flair_maxBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("flair_minBlue, flair_maxBlue: " + flair_minBlue + ", " + flair_maxBlue);
    }
  }

  public void makeSectors() {
    int sectorW = (int)(width - UI_PANEL_WIDTH - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsAcross - 1))) / this.sectorsAcross;
    int sectorH = (int)(height - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsDown - 1))) / sectorsDown;

    for (int y = 0; y < sectorsDown; y++) {
      for (int x = 0; x < sectorsAcross; x++) {
        PVector secCorner = new PVector(x*sectorW + GRID_OUTER_MARGIN + (x * GRID_INNER_MARGIN) + UI_PANEL_WIDTH, y*sectorH + GRID_OUTER_MARGIN + (y * GRID_INNER_MARGIN));
        Sector s = null;
        s = new FlairSector(x, y, secCorner, sectorW, sectorH);
        if (null != s) {
          sectors[x][y] = s;
        }
      }
    }
  }
}
class Grid {
  int sectorsAcross, sectorsDown;
  String sectorType;
  Sector[][] sectors;

  Grid(int _nx, int _ny, String _sectorType) {
    this.sectorsAcross = _nx;
    this.sectorsDown = _ny;

    // Parse for establishing proper sectors
    this.sectorType = _sectorType;
    this.sectors = new Sector[this.sectorsAcross][this.sectorsDown];
    makeSectors();
  }

  public void rebuild() {
    for (int x = 0; x < this.sectorsAcross; x++) {
      for (int y = 0; y < this.sectorsDown; y++) {
        Sector s = sectors[x][y];
        s.rebuild();
      }
    }
  }

  public void display() {
    for (int x = 0; x < this.sectorsAcross; x++) {
      for (int y = 0; y < this.sectorsDown; y++) {
        Sector s = sectors[x][y];
        s.display();
      }
    }
  }
  
  public void createUIComponents(){
    print("implement createUIComponents() in subclass");
  }
  
  public void setRangeValues(){
    print("implement setRangeValues() in subclass");
  }
  
  public void handleEvents(ControlEvent theControlEvent){
    print("implement handleEvents in subclass");
  }
  
  public void makeSectors(){
    print("implement makeSectors in subclass");
  }

}
class Sector {
  int xCoord, yCoord, w, h;
  PVector corner, center;

  Sector(int _x, int _y, PVector _corner, int _w, int _h) {
    this.xCoord = _x;
    this.yCoord = _y;
    this.corner = _corner;
    w = _w;
    h = _h;
    
    this.center = new PVector(this.corner.x + w/2, this.corner.y + h/2);
  }

  public void display() {
    if (debug) {
      debugDisplay();
    }
  }
  
  public void rebuild() {
     println("rebuild() not implemented in subclass");
  }

  public void debugDisplay() {
    noFill();
    stroke(200);
    rect(this.corner.x, this.corner.y, this.w, this.h);
  }
}
class Segment {
  int cornerTop, cornerBottom, stripeSide, w, h, r, g, b, sr, sg, sb;
  int mainColor, stripeColor, mainColorStroke;
  Segment() {
    this.w = (int)random(segments_minWidth, segments_maxWidth);
    this.h = (int)random(segments_minHeight, segments_maxHeight);
    this.r = (int)random(segments_minRed, segments_maxRed);
    this.g = (int)random(segments_minGreen, segments_maxGreen);
    this.b = (int)random(segments_minBlue, segments_maxBlue);
    this.sr = (int)random(segments_minStripeRed, segments_maxStripeRed);
    this.sg = (int)random(segments_minStripeGreen, segments_maxStripeGreen);
    this.sb = (int)random(segments_minStripeBlue, segments_maxStripeBlue);
    this.cornerTop = (int)random(segments_minCornerTop, segments_maxCornerTop);
    this.cornerBottom = (int)random(segments_minCornerBottom, segments_maxCornerBottom);
    this.stripeSide = (int)random(segments_minStripeSide, segments_maxStripeSide + 0.99f);
    
    mainColor = color(r,g,b);
    stripeColor = color(sr,sg,sb);
    int b = color(0);
    mainColorStroke = lerpColor(mainColor, b, 0.33f);
  }

  public void display() {

    fill(mainColor);
    stroke(mainColorStroke);
    
    rect(-this.w/2, -this.h/2, this.w, this.h, this.cornerTop, this.cornerTop, this.cornerBottom, this.cornerBottom);
    
    fill(stripeColor);
    stroke(0);
    strokeWeight(1);
    if (this.stripeSide == 1) {
      // Left
      float nh = this.h * 0.66f;
      float nw = this.w * 0.3f;
      float nTop = this.cornerTop * 0.5f;
      float nBot = this.cornerBottom * 0.5f;
      rect(-this.w/3, -this.h/3, nw, nh, nTop, nTop, nBot, nBot);
      
    } else if (this.stripeSide == 2) {
      // Top
      float nh = this.h * 0.3f;
      float nw = this.w * 0.66f;
      float nTop = this.cornerTop * 0.5f;
      float nBot = this.cornerBottom * 0.5f;
      rect(-this.w/3, -this.h/3, nw, nh, nTop, nTop, nBot, nBot);
    } else if (this.stripeSide == 3) {
      // Right
      float nh = this.h * 0.66f;
      float nw = this.w * 0.3f;
      float nTop = this.cornerTop * 0.5f;
      float nBot = this.cornerBottom * 0.5f;
      rect(this.w/3-nw, -this.h/3, nw, nh, nTop, nTop, nBot, nBot);
    } else if (this.stripeSide == 4) {
      // Bottom
      float nh = this.h * 0.3f;
      float nw = this.w * 0.66f;
      float nTop = this.cornerTop * 0.5f;
      float nBot = this.cornerBottom * 0.5f;
      rect(-this.w/3, this.h/3-nh, nw, nh, nTop, nTop, nBot, nBot);
    } else if (this.stripeSide == 0) {
     // don't draw a stripe 
    }
    
  }
}







class SegmentSector extends Sector {
  Segment segment;
  SegmentSector(int _x, int _y, PVector _corner, int _w, int _h) {
    super(_x, _y, _corner, _w, _h);
    rebuild();
  }
  public void rebuild() {
    segment = new Segment();
  }

  public void display() {
    if (debug) {
      debugDisplay();
    }

    pushMatrix();
    translate(this.center.x, this.center.y);
    this.segment.display();
    popMatrix();
  }
}


class SegmentGrid extends Grid {
  SegmentGrid(int _nx, int _ny, String _sectorType) {
    super(_nx, _ny, _sectorType);
    setRangeValues();
  }
  public void createUIComponents() {
    segmentsCornerBottomRange = cp5.addRange("bot. corners")
      // disable broadcasting since setRange and setRangeValues will trigger an event
      .setBroadcast(false) 
      .setPosition(10, 30)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(SEGMENTS_MIN_CORNER_RADIUS, SEGMENTS_MAX_CORNER_RADIUS) // CHANGE?
      .setRangeValues(SEGMENTS_MIN_CORNER_RADIUS, SEGMENTS_MAX_CORNER_RADIUS)
      .moveTo("segments")
      .setBroadcast(true);

    segmentsCornerTopRange = cp5.addRange("top corners")
      // disable broadcasting since setRange and setRangeValues will trigger an event
      .setBroadcast(false) 
      .setPosition(10, 70)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(SEGMENTS_MIN_CORNER_RADIUS, SEGMENTS_MAX_CORNER_RADIUS)
      .setRangeValues(SEGMENTS_MIN_CORNER_RADIUS, SEGMENTS_MAX_CORNER_RADIUS)
      .moveTo("segments")
      .setBroadcast(true);

    segmentsHeightRange = cp5.addRange("seg. height")
      .setBroadcast(false) 
      .setPosition(10, 110)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(SEGMENTS_MIN_HEIGHT, SEGMENTS_MAX_HEIGHT)
      .setRangeValues(SEGMENTS_MIN_HEIGHT, SEGMENTS_MAX_HEIGHT)
      .moveTo("segments")
      .setBroadcast(true);

    segmentsWidthRange = cp5.addRange("seg. width")
      .setBroadcast(false) 
      .setPosition(10, 150)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(SEGMENTS_MIN_WIDTH, SEGMENTS_MAX_WIDTH)
      .setRangeValues(SEGMENTS_MIN_WIDTH, SEGMENTS_MAX_WIDTH)
      .moveTo("segments")
      .setBroadcast(true);

    // colors
    segmentsRedRange = cp5.addRange("seg. red")
      .setBroadcast(false) 
      .setPosition(10, 230)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("segments")
      .setBroadcast(true);

    segmentsGreenRange = cp5.addRange("seg. green")
      .setBroadcast(false) 
      .setPosition(10, 270)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("segments")
      .setBroadcast(true);

    segmentsBlueRange = cp5.addRange("seg. blue")
      .setBroadcast(false) 
      .setPosition(10, 310)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("segments")
      .setBroadcast(true);


    // Stripe Colors
    segmentsStripeRedRange = cp5.addRange("stripe red")
      .setBroadcast(false) 
      .setPosition(10, 390)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("segments")
      .setBroadcast(true);

    segmentsStripeGreenRange = cp5.addRange("stripe green")
      .setBroadcast(false) 
      .setPosition(10, 430)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("segments")
      .setBroadcast(true);

    segmentsStripeBlueRange = cp5.addRange("stripe blue")
      .setBroadcast(false) 
      .setPosition(10, 470)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("segments")
      .setBroadcast(true);

    segmentsStripeSideRange = cp5.addRange("stripe side")
      .setBroadcast(false) 
      .setPosition(10, 510)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(SEGMENTS_MIN_SIDE, SEGMENTS_MAX_SIDE)
      .setRangeValues(SEGMENTS_MIN_SIDE, SEGMENTS_MAX_SIDE)
      .moveTo("segments")
      .setBroadcast(true);
  }

  public void setRangeValues() {
    segments_minWidth = SEGMENTS_MIN_WIDTH;
    segments_maxWidth = SEGMENTS_MAX_WIDTH;
    segments_minHeight = SEGMENTS_MIN_HEIGHT;
    segments_maxHeight = SEGMENTS_MAX_HEIGHT;

    segments_minCornerBottom = SEGMENTS_MIN_WIDTH;
    segments_maxCornerBottom = SEGMENTS_MAX_WIDTH;
    segments_minCornerTop = SEGMENTS_MIN_WIDTH;
    segments_maxCornerTop = SEGMENTS_MAX_WIDTH;

    segments_minRed = MIN_COLOR;
    segments_maxRed = MAX_COLOR;
    segments_minGreen = MIN_COLOR;
    segments_maxGreen = MAX_COLOR;
    segments_minBlue = MIN_COLOR;
    segments_maxBlue = MAX_COLOR;

    segments_minStripeRed = MIN_COLOR;
    segments_maxStripeRed = MAX_COLOR;
    segments_minStripeGreen = MIN_COLOR;
    segments_maxStripeGreen = MAX_COLOR;
    segments_minStripeBlue = MIN_COLOR;
    segments_maxStripeBlue = MAX_COLOR;

    segments_minStripeSide = SEGMENTS_MIN_SIDE;
    segments_maxStripeSide = SEGMENTS_MAX_SIDE;

    try {
      segmentsWidthRange.setRangeValues(segments_minWidth, segments_maxWidth);
      segmentsHeightRange.setRangeValues(segments_minHeight, segments_maxHeight);

      segmentsCornerTopRange.setRangeValues(segments_minCornerTop, segments_maxCornerTop);
      segmentsCornerBottomRange.setRangeValues(segments_minCornerBottom, segments_maxCornerBottom);

      segmentsRedRange.setRangeValues(segments_minRed, segments_maxRed);
      segmentsGreenRange.setRangeValues(segments_minGreen, segments_maxGreen);
      segmentsBlueRange.setRangeValues(segments_minBlue, segments_maxBlue);

      segmentsStripeRedRange.setRangeValues(segments_minStripeRed, segments_maxStripeRed);
      segmentsStripeGreenRange.setRangeValues(segments_minStripeGreen, segments_maxStripeGreen);
      segmentsStripeBlueRange.setRangeValues(segments_minStripeBlue, segments_maxStripeBlue);
    }
    catch(NullPointerException e) {
    }
    finally {
    }
  }

  public void handleEvents(ControlEvent theControlEvent) {
    if (theControlEvent.isFrom(segmentsRedRange)) {
      segments_minRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minRed, segments_maxRed: " + segments_minRed + ", " + segments_maxRed);
    }

    if (theControlEvent.isFrom(segmentsGreenRange)) {
      segments_minGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minGreen, segments_maxGreen: " + segments_minGreen + ", " + segments_maxGreen);
    }

    if (theControlEvent.isFrom(segmentsBlueRange)) {
      segments_minBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minBlue, segments_maxBlue: " + segments_minBlue + ", " + segments_maxBlue);
    }

    if (theControlEvent.isFrom(segmentsCornerBottomRange)) {
      segments_minCornerBottom = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxCornerBottom = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minCornerBottom, segments_maxCornerBottom: " + segments_minCornerBottom + ", " + segments_maxCornerBottom);
    }  

    if (theControlEvent.isFrom(segmentsCornerTopRange)) {
      segments_minCornerTop = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxCornerTop = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minCornerTop, segments_maxCornerTop: " + segments_minCornerTop + ", " + segments_maxCornerTop);
    }  

    if (theControlEvent.isFrom(segmentsWidthRange)) {
      segments_minWidth = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxWidth = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minWidth, segments_maxWidth: " + segments_minWidth + ", " + segments_maxWidth);
    }  

    if (theControlEvent.isFrom(segmentsHeightRange)) {
      segments_minHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minHeight, segments_maxHeight: " + segments_minHeight + ", " + segments_maxHeight);
    }  



    // Segment Stripes
    if (theControlEvent.isFrom(segmentsStripeRedRange)) {
      segments_minStripeRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxStripeRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minStripeRed, segments_maxStripeRed: " + segments_minStripeRed + ", " + segments_maxStripeRed);
    }

    if (theControlEvent.isFrom(segmentsStripeGreenRange)) {
      segments_minStripeGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxStripeGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minStripeGreen, segments_maxStripeGreen: " + segments_minStripeGreen + ", " + segments_maxStripeGreen);
    }

    if (theControlEvent.isFrom(segmentsStripeBlueRange)) {
      segments_minStripeBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxStripeBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minStripeBlue, segments_maxStripeBlue: " + segments_minStripeBlue + ", " + segments_maxStripeBlue);
    }

    if (theControlEvent.isFrom(segmentsStripeSideRange)) {
      segments_minStripeSide = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      segments_maxStripeSide = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("segments_minStripeSide, segments_maxStripeSide: " + segments_minStripeSide + ", " + segments_maxStripeSide);
    }
  }

  public void makeSectors() {
    int sectorW = (int)(width - UI_PANEL_WIDTH - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsAcross - 1))) / this.sectorsAcross;
    int sectorH = (int)(height - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsDown - 1))) / sectorsDown;

    for (int y = 0; y < sectorsDown; y++) {
      for (int x = 0; x < sectorsAcross; x++) {
        PVector secCorner = new PVector(x*sectorW + GRID_OUTER_MARGIN + (x * GRID_INNER_MARGIN) + UI_PANEL_WIDTH, y*sectorH + GRID_OUTER_MARGIN + (y * GRID_INNER_MARGIN));
        Sector s = null;
        s = new SegmentSector(x, y, secCorner, sectorW, sectorH);
        if (null != s) {
          sectors[x][y] = s;
        }
      }
    }
  }
}
class Ship {
  int numWings, numSegments, segmentSpacing, backboneWidth, backboneHeight;
  boolean topWings, bottomWings;
  ArrayList<PVector> wingLocations;
  float bendiness, centerOffset;
  PVector p1, p2, p3, p4, p5, p6, w1, w2, w3, w4, w5, w6;
  float shipLength, shipHeight;

  Flair flair;
  Cockpit cockpit;
  Segment segment;
  Tail tail;
  Wing wing;
  Ship() {
    this.numWings = (int)random(ships_minWings, ships_maxWings + 0.99f);
    this.numSegments = (int)random(ships_minSegments, ships_maxSegments + 0.99f);
    this.bendiness = random(ships_minAmplitude, ships_maxAmplitude);
    this.segmentSpacing = 2; // TODO: parameterize
    this.topWings = ships_wingsTop;
    this.bottomWings = ships_wingsBottom;

    flair = new Flair();
    cockpit = new Cockpit();
    segment = new Segment();
    tail = new Tail();
    wing = new Wing();

    this.backboneWidth = (this.numSegments * segment.w) + (this.segmentSpacing * (this.numSegments - 1));
    this.backboneHeight = 60;

    // Constraint to prevent it from being too bendy
    this.centerOffset = max(0, min(50, (segment.h/2) * this.bendiness));

    // These define the backbone
    p1 = new PVector(-this.backboneWidth/2, -this.backboneHeight/2);
    p2 = new PVector(0, -this.backboneHeight/2 - this.centerOffset);
    p3 = new PVector(this.backboneWidth/2, -this.backboneHeight/2);
    p4 = new PVector(this.backboneWidth/2, this.backboneHeight/2);
    p5 = new PVector(0, this.backboneHeight/2 - this.centerOffset);
    p6 = new PVector(-this.backboneWidth/2, this.backboneHeight/2);

    // Candidate wing positions
    // Use z value to store upright or inverted.
    w1 = PVector.lerp(p1, p2, 0.33f);
    w1.z = 0;
    w2 = p2;
    w2.z = 0;
    w3 = PVector.lerp(p3, p2, 0.33f);
    w3.z = 0;
    w4 = PVector.lerp(p6, p5, 0.33f);
    w4.z = 1;
    w5 = p5;
    w5.z = 1;
    w6 = PVector.lerp(p4, p5, 0.33f);
    w6.z = 1;

    wingLocations = new ArrayList<PVector>();

    ArrayList<PVector> candidateSpots = new ArrayList<PVector>();
    if (this.topWings) {
      candidateSpots.add(w1);
      candidateSpots.add(w2);
      candidateSpots.add(w3);
    }
    if (this.bottomWings) {
      candidateSpots.add(w4);
      candidateSpots.add(w5);
      candidateSpots.add(w6);
    }

    // Constraint
    // We can only draw as many wings as we have spots for...
    numWings = min(numWings, candidateSpots.size());

    for (int i = 0; i < numWings; i++) {
      int idx = (int)random(0, candidateSpots.size());
      wingLocations.add(candidateSpots.get(idx));
      candidateSpots.remove(idx);
    }

    // If you want wings but have both boxes unchecked, you get top wings
    if (!this.topWings && !this.bottomWings) {
      if (this.numWings > 0) this.topWings = true;
    }

    shipLength = this.backboneWidth + this.cockpit.w + this.tail.w + this.tail.engineWidth;
    shipHeight = max(this.cockpit.h/2, max(this.segment.h/2, this.tail.h/2)) + this.tail.h*2;
  }

  public void display() {
    // wings
    if (debug) {
      // Mark the "attachment" points
      ellipseMode(CENTER);
      fill(flair.mainColor);
      noStroke();
      ellipse(w1.x, w1.y, 10, 10);
      ellipse(w2.x, w2.y, 10, 10);
      ellipse(w3.x, w3.y, 10, 10);
      ellipse(w4.x, w4.y, 10, 10);
      ellipse(w5.x, w5.y, 10, 10);
      ellipse(w6.x, w6.y, 10, 10);
    }

    for (PVector p : wingLocations) {
      if (p.z == 0) {
        // top
        pushMatrix();
        translate(p.x, p.y - wing.h/2 + this.backboneHeight/2);
        wing.display();
        popMatrix();
      } else {
        // bottom
        pushMatrix();
        translate(p.x, p.y + wing.h/2 - this.backboneHeight/2);
        wing.displayInverted();
        popMatrix();
      }
    }

    // backbone - add center joint for bendiness
    // Also, don't quite make it as long as it should be so that segments cover most
    fill(0);
    noStroke();

    beginShape();
    vertex(p1.x+10, p1.y);
    vertex(p2.x, p2.y);
    vertex(p3.x-10, p3.y);
    vertex(p4.x-10, p4.y);
    vertex(p5.x, p5.y);
    vertex(p6.x+10, p6.y);
    endShape(CLOSE);

    // segments
    float segCenterX = -this.backboneWidth/2 + this.segment.w/2;

    for (int i = 0; i < this.numSegments; i++) {

      // Calculate y position
      float yOffsetLerpPercent, segCenterY;
      if (segCenterX == 0) {
        segCenterX += 0.01f;
      }
      if (segCenterX < 0) {
        yOffsetLerpPercent = (this.backboneWidth/2 - abs(segCenterX)) / (this.backboneWidth/2);
        PVector topAnchor = PVector.lerp(p1, p2, yOffsetLerpPercent);
        PVector bottomAnchor = PVector.lerp(p6, p5, yOffsetLerpPercent);
        PVector midAnchor = PVector.lerp(topAnchor, bottomAnchor, 0.5f);
        segCenterY = midAnchor.y;
      } else {
        yOffsetLerpPercent = abs(segCenterX) / (this.backboneWidth/2);
        PVector topAnchor = PVector.lerp(p2, p3, yOffsetLerpPercent);
        PVector bottomAnchor = PVector.lerp(p5, p4, yOffsetLerpPercent);
        PVector midAnchor = PVector.lerp(topAnchor, bottomAnchor, 0.5f);
        segCenterY = midAnchor.y;
      }


      pushMatrix();
      translate(segCenterX, segCenterY); // handle y
      segment.display();
      segCenterX += segment.w + segmentSpacing;
      popMatrix();
    }

    // cockpit
    float additionalXOffset = 0;
    if (cockpit.cockpit_type == "type2") {
      additionalXOffset = cockpit.w/2 * 0.9f;
    }
    noStroke();
    noFill();
    pushMatrix();
    translate(-this.backboneWidth/2 - cockpit.w/2 + 5 + additionalXOffset, 0);
    cockpit.display();
    popMatrix();

    // tail
    noStroke();
    noFill();
    pushMatrix();
    translate(this.backboneWidth/2 + tail.w/2 - 10, 0);
    tail.display();
    popMatrix();
  }
}



class ShipSector extends Sector {
  Ship ship;
  ShipSector(int _x, int _y, PVector _corner, int _w, int _h) {
    super(_x, _y, _corner, _w, _h);
    rebuild();
  }
  public void rebuild() {
    ship = new Ship();
  }

  public void display() {
    if (debug) {
      debugDisplay();
    }

    pushMatrix();
    translate(this.center.x, this.center.y);
    this.ship.display();
    popMatrix();
  }
}


class ShipGrid extends Grid {
  ShipGrid(int _nx, int _ny, String _sectorType) {
    super(_nx, _ny, _sectorType);
    setRangeValues();
  }
  public void createUIComponents() {
    shipsSegmentsRange = cp5.addRange("segments")
      .setBroadcast(false) 
      .setPosition(10, 30)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(SHIPS_MIN_SEGMENTS, SHIPS_MAX_SEGMENTS)
      .setRangeValues(SHIPS_MIN_SEGMENTS, SHIPS_MAX_SEGMENTS)
      .moveTo("ships")
      .setBroadcast(true);

    shipsAmplitudeRange = cp5.addRange("bendiness")
      .setBroadcast(false) 
      .setPosition(10, 70)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(SHIPS_MIN_AMPLITUDE, SHIPS_MAX_AMPLITUDE)
      .setRangeValues(SHIPS_MIN_AMPLITUDE, SHIPS_MAX_AMPLITUDE)
      .moveTo("ships")
      .setBroadcast(true);

    shipsWingsRange = cp5.addRange("num. wings")
      .setBroadcast(false) 
      .setPosition(10, 110)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(SHIPS_MIN_WINGS, SHIPS_MAX_WINGS)
      .setRangeValues(SHIPS_MIN_WINGS, SHIPS_MAX_WINGS)
      .moveTo("ships")
      .setBroadcast(true);

    shipsWingPositions = cp5.addCheckBox("wing positions")
      .setPosition(10, 190)
      .setSize(30, 30)
      .setItemsPerRow(2)
      .setSpacingColumn(70)
      .setSpacingRow(20)
      .addItem("top wings", 1)
      .addItem("bottom wings", 2)
      .moveTo("ships")
      .toggle(0)
      .toggle(1)
      ;
  }

  public void setRangeValues() {
    ships_minSegments = SHIPS_MIN_SEGMENTS;
    ships_maxSegments = SHIPS_MAX_SEGMENTS;
    ships_minAmplitude = SHIPS_MIN_AMPLITUDE;
    ships_maxAmplitude = SHIPS_MAX_AMPLITUDE;
    ships_minWings = SHIPS_MIN_WINGS;
    ships_maxWings = SHIPS_MAX_WINGS;

    ships_wingsTop = true;
    ships_wingsBottom = true;


    try {
      shipsSegmentsRange.setRangeValues(ships_minSegments, ships_maxSegments);
      shipsAmplitudeRange.setRangeValues(ships_minAmplitude, ships_maxAmplitude);
      shipsWingsRange.setRangeValues(ships_minWings, ships_maxWings);

      float[] v = {1, 1};
      shipsWingPositions.setArrayValue(v);
    }
    catch(NullPointerException e) {
    }
    finally {
    }
  }

  public void handleEvents(ControlEvent theControlEvent) {
    if (theControlEvent.isFrom(shipsSegmentsRange)) {
      ships_minSegments = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      ships_maxSegments = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("ships_minSegments, ships_maxSegments: " + ships_minSegments + ", " + ships_maxSegments);
    }

    if (theControlEvent.isFrom(shipsAmplitudeRange)) {
      ships_minAmplitude = theControlEvent.getController().getArrayValue(0);
      ships_maxAmplitude = theControlEvent.getController().getArrayValue(1);
      println("ships_minAmplitude, ships_maxAmplitude: " + ships_minAmplitude + ", " + ships_maxAmplitude);
    }

    if (theControlEvent.isFrom(shipsWingsRange)) {
      ships_minWings = (int)theControlEvent.getController().getArrayValue(0);
      ships_maxWings = (int)theControlEvent.getController().getArrayValue(1);
      println("ships_minWings, ships_maxWings: " + ships_minWings + ", " + ships_maxWings);
    }

    if (theControlEvent.isFrom(shipsWingPositions)) {
      ships_wingsTop = PApplet.parseInt(shipsWingPositions.getArrayValue()[0]) == 1 ? true : false;
      ships_wingsBottom = PApplet.parseInt(shipsWingPositions.getArrayValue()[1]) == 1 ? true : false;
      println("shipsWingPositions: top, bottom: " + ships_wingsTop + ", " + ships_wingsBottom);
    }
  }

  public void makeSectors() {
    int sectorW = (int)(width - UI_PANEL_WIDTH - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsAcross - 1))) / this.sectorsAcross;
    int sectorH = (int)(height - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsDown - 1))) / sectorsDown;

    for (int y = 0; y < sectorsDown; y++) {
      for (int x = 0; x < sectorsAcross; x++) {
        PVector secCorner = new PVector(x*sectorW + GRID_OUTER_MARGIN + (x * GRID_INNER_MARGIN) + UI_PANEL_WIDTH, y*sectorH + GRID_OUTER_MARGIN + (y * GRID_INNER_MARGIN));
        Sector s = null;
        s = new ShipSector(x, y, secCorner, sectorW, sectorH);
        if (null != s) {
          sectors[x][y] = s;
        }
      }
    }
  }
}
class Tail {
  int w, h, r, g, b, engines;
  int mainColor, mainColorStroke;
  float engineWidth, engineHeight;
  Tail() {
    this.w = (int)random(tails_minWidth, tails_maxWidth);
    this.h = (int)random(tails_minHeight, tails_maxHeight);
    this.r = (int)random(tails_minRed, tails_maxRed);
    this.g = (int)random(tails_minGreen, tails_maxGreen);
    this.b = (int)random(tails_minBlue, tails_maxBlue);
    this.engines = (int)random(tails_minEngines, tails_maxEngines + 0.99f);
    
    this.mainColor = color(this.r, this.g, this.b);
    int b = color(0);
    this.mainColorStroke = lerpColor(this.mainColor, b, 0.33f);
    this.engineWidth = max(this.w/3,75);
    this.engineHeight = this.h/max(this.engines,2);
  }

  public void display() {
    // Engine triangles are dark grey
    fill(80);
    stroke(110);
    
    float x1, y1, x2, y2, x3, y3, yCenter;
    
    // TODO: Fix this logic so that the for loop handles all of it
    // use lerp against the height
    if (this.engines == 1) {
      yCenter = 0;
      x1 = this.w/2 - 20;
      y1 = yCenter;
      x2 = x1 + engineWidth;
      y2 = yCenter - engineHeight/2;
      x3 = x2;
      y3 = yCenter + engineHeight/2;
      triangle(x1,y1,x2,y2,x3,y3);
    } else {
      for (int i = 0; i < this.engines; i++) {
         yCenter = (this.engines * engineHeight*0.7f) - engineHeight - (i * engineHeight*1.1f); 
         x1 = this.w/2 - 20;
         y1 = yCenter;
         x2 = x1 + engineWidth;
         y2 = yCenter - engineHeight/2;
         x3 = x2;
         y3 = yCenter + engineHeight/2;
         triangle(x1,y1,x2,y2,x3,y3);
      }
    }
    
    fill(mainColor);
    stroke(mainColorStroke);
    
    beginShape();
    vertex(-this.w/2,-this.h/2 * 0.8f);
    vertex(this.w/2, -this.h/2);
    vertex(this.w/2, this.h/2);
    vertex(-this.w/2, this.h/2 * 0.8f);
    endShape(CLOSE);
  }
}




class TailSector extends Sector {
  Tail tail;
  TailSector(int _x, int _y, PVector _corner, int _w, int _h) {
    super(_x, _y, _corner, _w, _h);
    rebuild();
  }
  public void rebuild() {
    tail = new Tail();
  }

  public void display() {
    if (debug) {
      debugDisplay();
    }

    pushMatrix();
    translate(this.center.x, this.center.y);
    this.tail.display();
    popMatrix();
  }
}




class TailGrid extends Grid {
  TailGrid(int _nx, int _ny, String _sectorType) {
    super(_nx, _ny, _sectorType);
    setRangeValues();
  }
  public void createUIComponents() {
    tailsWidthRange = cp5.addRange("tail width")
      // disable broadcasting since setRange and setRangeValues will trigger an event
      .setBroadcast(false) 
      .setPosition(10, 30)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(TAILS_MIN_WIDTH, TAILS_MAX_WIDTH)
      .setRangeValues(TAILS_MIN_WIDTH, TAILS_MAX_WIDTH)
      .moveTo("tails")
      .setBroadcast(true);

    tailsHeightRange = cp5.addRange("tail height")
      .setBroadcast(false) 
      .setPosition(10, 70)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(TAILS_MIN_HEIGHT, TAILS_MAX_HEIGHT)
      .setRangeValues(TAILS_MIN_HEIGHT, TAILS_MAX_HEIGHT)
      .moveTo("tails")
      .setBroadcast(true);

    tailsEnginesRange = cp5.addRange("engines")
      .setBroadcast(false) 
      .setPosition(10, 150)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(TAILS_MIN_ENGINES, TAILS_MAX_ENGINES)
      .setRangeValues(TAILS_MIN_ENGINES, TAILS_MAX_ENGINES)
      .moveTo("tails")
      .setBroadcast(true);

    tailsRedRange = cp5.addRange("tail red")
      .setBroadcast(false) 
      .setPosition(10, 230)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("tails")
      .setBroadcast(true);

    tailsGreenRange = cp5.addRange("tail green")
      .setBroadcast(false) 
      .setPosition(10, 270)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("tails")
      .setBroadcast(true);

    tailsBlueRange = cp5.addRange("tail blue")
      .setBroadcast(false) 
      .setPosition(10, 310)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("tails")
      .setBroadcast(true);
  }

  public void setRangeValues() {
    tails_minWidth = TAILS_MIN_WIDTH;
    tails_maxWidth = TAILS_MAX_WIDTH;
    tails_minHeight = TAILS_MIN_HEIGHT;
    tails_maxHeight = TAILS_MAX_HEIGHT;
    tails_minEngines = TAILS_MIN_ENGINES;
    tails_maxEngines = TAILS_MAX_ENGINES;
    tails_minRed = MIN_COLOR;
    tails_maxRed = MAX_COLOR;
    tails_minGreen = MIN_COLOR;
    tails_maxGreen = MAX_COLOR;
    tails_minBlue = MIN_COLOR;
    tails_maxBlue = MAX_COLOR;

    try {
      tailsWidthRange.setRangeValues(tails_minWidth, tails_maxWidth);
      tailsHeightRange.setRangeValues(tails_minHeight, tails_maxHeight);
      tailsEnginesRange.setRangeValues(tails_minEngines, tails_maxEngines);
      tailsRedRange.setRangeValues(tails_minRed, tails_maxRed);
      tailsGreenRange.setRangeValues(tails_minGreen, tails_maxGreen);
      tailsBlueRange.setRangeValues(tails_minBlue, tails_maxBlue);
    }
    catch(NullPointerException e) {
    }
    finally {
    }
  }

  public void handleEvents(ControlEvent theControlEvent) {
    if (theControlEvent.isFrom(tailsRedRange)) {
      tails_minRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      tails_maxRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("tails_minRed, tails_maxRed: " + tails_minRed + ", " + tails_maxRed);
    }

    if (theControlEvent.isFrom(tailsGreenRange)) {
      tails_minGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      tails_maxGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("tails_minGreen, tails_maxGreen: " + tails_minGreen + ", " + tails_maxGreen);
    }

    if (theControlEvent.isFrom(tailsBlueRange)) {
      tails_minBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      tails_maxBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("tails_minBlue, tails_maxBlue: " + tails_minBlue + ", " + tails_maxBlue);
    }

    if (theControlEvent.isFrom(tailsWidthRange)) {
      tails_minWidth = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      tails_maxWidth = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("tails_minWidth, tails_maxWidth: " + tails_minWidth + ", " + tails_maxWidth);
    }  

    if (theControlEvent.isFrom(tailsHeightRange)) {
      tails_minHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      tails_maxHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("tails_minHeight, tails_maxHeight: " + tails_minHeight + ", " + tails_maxHeight);
    }  

    if (theControlEvent.isFrom(tailsEnginesRange)) {
      tails_minEngines = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      tails_maxEngines = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("tails_minEngines, tails_maxEngines: " + tails_minEngines + ", " + tails_maxEngines);
    }  
  }

  public void makeSectors() {
    int sectorW = (int)(width - UI_PANEL_WIDTH - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsAcross - 1))) / this.sectorsAcross;
    int sectorH = (int)(height - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsDown - 1))) / sectorsDown;

    for (int y = 0; y < sectorsDown; y++) {
      for (int x = 0; x < sectorsAcross; x++) {
        PVector secCorner = new PVector(x*sectorW + GRID_OUTER_MARGIN + (x * GRID_INNER_MARGIN) + UI_PANEL_WIDTH, y*sectorH + GRID_OUTER_MARGIN + (y * GRID_INNER_MARGIN));
        Sector s = null;
        s = new TailSector(x, y, secCorner, sectorW, sectorH);
        if (null != s) {
          sectors[x][y] = s;
        }
      }
    }
  }
}
class Wing {
  int wTop, wBottom, h, r, g, b;
  float shear, rotation;
  int fill_color, outline_color;
  PVector upperLeft, upperRight, lowerRight, lowerLeft;
  PVector iUpperLeft, iUpperRight, iLowerRight, iLowerLeft; // inverted
  PVector midBottom, midTop, midPoint, lowerThird, upperThird;
  PVector iMidBottom, iMidTop, iMidPoint, iLowerThird, iUpperThird; // inverted
  Flair flair;
  Wing() {
    this.wTop = (int)random(wings_minWidthTop, wings_maxWidthTop);
    this.wBottom = (int)random(wings_minWidthBottom, wings_maxWidthBottom);
    this.h = (int)random(wings_minHeight, wings_maxHeight);
    this.r = (int)random(wings_minRed, wings_maxRed);
    this.g = (int)random(wings_minGreen, wings_maxGreen);
    this.b = (int)random(wings_minBlue, wings_maxBlue);
    this.shear = random(wings_minShear, wings_maxShear);
    this.rotation = random(wings_minRotation, wings_maxRotation);

    this.fill_color = color(this.r, this.g, this.b);
    int c = color(0);
    this.outline_color = lerpColor(fill_color, c, 0.33f);

    float offsetTop = this.shear * this.wTop / 2;

    // wing on top
    upperLeft = new PVector(-this.wTop/2 + offsetTop, -this.h/2);
    upperRight = new PVector(this.wTop/2 + offsetTop, -this.h/2);
    lowerRight = new PVector(this.wBottom/2, this.h/2);
    lowerLeft = new PVector(-this.wBottom/2, this.h/2);

    midBottom = PVector.lerp(lowerLeft, lowerRight, 0.5f);
    midTop = PVector.lerp(upperLeft, upperRight, 0.5f);
    midPoint = PVector.lerp(midBottom, midTop, 0.5f);
    lowerThird = PVector.lerp(midBottom, midTop, 0.25f);
    upperThird = PVector.lerp(midBottom, midTop, 0.75f);

    // wing on bottom
    iUpperLeft = new PVector(-this.wBottom/2, -this.h/2);
    iUpperRight = new PVector(this.wBottom/2, -this.h/2);
    iLowerRight = new PVector(this.wTop/2 + offsetTop, this.h/2);
    iLowerLeft = new PVector(-this.wTop/2 + offsetTop, this.h/2);

    iMidBottom = PVector.lerp(iUpperLeft, iUpperRight, 0.5f);
    iMidTop = PVector.lerp(iLowerLeft, iLowerRight, 0.5f);
    iMidPoint = PVector.lerp(iMidBottom, iMidTop, 0.5f);
    iLowerThird = PVector.lerp(iMidBottom, iMidTop, 0.25f);
    iUpperThird = PVector.lerp(iMidBottom, iMidTop, 0.75f);

    flair = new Flair();
  }

  public void display() {
    fill(this.fill_color);
    stroke(this.outline_color);

    pushMatrix();
    rotate(this.rotation);
    beginShape();
    vertex(upperLeft.x, upperLeft.y);
    vertex(upperRight.x, upperRight.y);
    vertex(lowerRight.x, lowerRight.y);
    vertex(lowerLeft.x, lowerLeft.y);
    endShape(CLOSE);

    pushMatrix();
    translate(midPoint.x, midPoint.y);
    flair.display();
    popMatrix();

    pushMatrix();
    translate(lowerThird.x, lowerThird.y);
    flair.display();
    popMatrix();

    pushMatrix();
    translate(upperThird.x, upperThird.y);
    flair.display();
    popMatrix();

    popMatrix();
  }
  
  // For drawing on the bottom of a ship
  public void displayInverted() {
    fill(this.fill_color);
    stroke(this.outline_color);
    
    pushMatrix();
      rotate(-this.rotation);
      beginShape();
      vertex(iUpperLeft.x, iUpperLeft.y);
      vertex(iUpperRight.x, iUpperRight.y);
      vertex(iLowerRight.x, iLowerRight.y);
      vertex(iLowerLeft.x, iLowerLeft.y);
      endShape(CLOSE);
      
      pushMatrix();
      translate(iMidPoint.x, iMidPoint.y);
      flair.displayReverse();
      popMatrix();
  
      pushMatrix();
      translate(iLowerThird.x, iLowerThird.y);
      flair.displayReverse();
      popMatrix();
  
      pushMatrix();
      translate(iUpperThird.x, iUpperThird.y);
      flair.displayReverse();
      popMatrix();
    popMatrix();
  }
}




class WingSector extends Sector {
  Wing wing;
  WingSector(int _x, int _y, PVector _corner, int _w, int _h) {
    super(_x, _y, _corner, _w, _h);
    rebuild();
  }

  public void rebuild() {
    wing = new Wing();
  }

  public void display() {
    if (debug) {
      debugDisplay();
    }

    pushMatrix();
    translate(this.center.x, this.center.y);
    this.wing.display();
    popMatrix();
  }
}





class WingGrid extends Grid {
  WingGrid(int _nx, int _ny, String _sectorType) {
    super(_nx, _ny, _sectorType);
    setRangeValues();
  }
  public void createUIComponents() {
    wingsWidthTopRange = cp5.addRange("wing top")
      // disable broadcasting since setRange and setRangeValues will trigger an event
      .setBroadcast(false) 
      .setPosition(10, 30)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(WINGS_MIN_WIDTH, WINGS_MAX_WIDTH)
      .setRangeValues(WINGS_MIN_WIDTH, WINGS_MAX_WIDTH)
      .moveTo("wings")
      .setBroadcast(true);

    wingsWidthBottomRange = cp5.addRange("wing base")
      // disable broadcasting since setRange and setRangeValues will trigger an event
      .setBroadcast(false) 
      .setPosition(10, 70)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(WINGS_MIN_WIDTH, WINGS_MAX_WIDTH)
      .setRangeValues(WINGS_MIN_WIDTH, WINGS_MAX_WIDTH)
      .moveTo("wings")
      .setBroadcast(true);

    wingsHeightRange = cp5.addRange("wing height")
      .setBroadcast(false) 
      .setPosition(10, 110)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(WINGS_MIN_HEIGHT, WINGS_MAX_HEIGHT)
      .setRangeValues(WINGS_MIN_HEIGHT, WINGS_MAX_HEIGHT)
      .moveTo("wings")
      .setBroadcast(true);

    wingsRotationRange = cp5.addRange("wing rotation")
      .setBroadcast(false) 
      .setPosition(10, 150)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(ROTATION_MIN, ROTATION_MAX)
      .setRangeValues(ROTATION_MIN, ROTATION_MIN)
      .moveTo("wings")
      .setBroadcast(true);

    wingsShearRange = cp5.addRange("wing shear")
      .setBroadcast(false) 
      .setPosition(10, 190)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(SHEAR_MIN, SHEAR_MAX)
      .setRangeValues(SHEAR_MIN, SHEAR_MIN)
      .moveTo("wings")
      .setBroadcast(true);

    // colors
    wingsRedRange = cp5.addRange("wing red")
      .setBroadcast(false) 
      .setPosition(10, 230)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("wings")
      .setBroadcast(true);

    wingsGreenRange = cp5.addRange("wing green")
      .setBroadcast(false) 
      .setPosition(10, 270)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("wings")
      .setBroadcast(true);

    wingsBlueRange = cp5.addRange("wing blue")
      .setBroadcast(false) 
      .setPosition(10, 310)
      .setSize(180, 30)
      .setHandleSize(20)
      .setRange(MIN_COLOR, MAX_COLOR)
      .setRangeValues(MIN_COLOR, MAX_COLOR)
      .moveTo("wings")
      .setBroadcast(true);
  }

  public void setRangeValues() {
    wings_minWidthTop = WINGS_MIN_WIDTH;
    wings_maxWidthTop = WINGS_MAX_WIDTH;
    wings_minWidthBottom = WINGS_MIN_WIDTH;
    wings_maxWidthBottom = WINGS_MAX_WIDTH;
    wings_minHeight = WINGS_MIN_HEIGHT;
    wings_maxHeight = WINGS_MAX_HEIGHT;
    wings_minRotation = ROTATION_MIN;
    wings_maxRotation = ROTATION_MIN;
    wings_minShear = SHEAR_MIN;
    wings_maxShear = SHEAR_MIN;

    wings_minRed = MIN_COLOR;
    wings_maxRed = MAX_COLOR;
    wings_minGreen = MIN_COLOR;
    wings_maxGreen = MAX_COLOR;
    wings_minBlue = MIN_COLOR;
    wings_maxBlue = MAX_COLOR;

    try {
      wingsWidthTopRange.setRangeValues(wings_minWidthTop, wings_maxWidthTop);
      wingsWidthBottomRange.setRangeValues(wings_minWidthBottom, wings_maxWidthBottom);
      wingsHeightRange.setRangeValues(wings_minHeight, wings_maxHeight);
      wingsShearRange.setRangeValues(wings_minShear, wings_maxShear);
      wingsRotationRange.setRangeValues(wings_minRotation, wings_maxRotation);

      wingsRedRange.setRangeValues(wings_minRed, wings_maxRed);
      wingsGreenRange.setRangeValues(wings_minGreen, wings_maxGreen);
      wingsBlueRange.setRangeValues(wings_minBlue, wings_maxBlue);
    }
    catch(NullPointerException e) {
    }
    finally {
    }
  }

  public void handleEvents(ControlEvent theControlEvent) {
    if (theControlEvent.isFrom(wingsRedRange)) {
      wings_minRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      wings_maxRed = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("wings_minRed, wings_maxRed: " + wings_minRed + ", " + wings_maxRed);
    }

    if (theControlEvent.isFrom(wingsGreenRange)) {
      wings_minGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      wings_maxGreen = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("wings_minGreen, cockpit_maxGreen: " + wings_minGreen + ", " + cockpit_maxGreen);
    }

    if (theControlEvent.isFrom(wingsBlueRange)) {
      wings_minBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      wings_maxBlue = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("wings_minBlue, wings_maxBlue: " + wings_minBlue + ", " + wings_maxBlue);
    }

    if (theControlEvent.isFrom(wingsWidthTopRange)) {
      wings_minWidthTop = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      wings_maxWidthTop = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("wings_minWidthTop, wings_maxWidthTop: " + wings_minWidthTop + ", " + wings_maxWidthTop);
    }  

    if (theControlEvent.isFrom(wingsWidthBottomRange)) {
      wings_minWidthBottom = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      wings_maxWidthBottom = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("wings_minWidthBottom, wings_maxWidthBottom: " + wings_minWidthBottom + ", " + wings_maxWidthBottom);
    }  

    if (theControlEvent.isFrom(wingsHeightRange)) {
      wings_minHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      wings_maxHeight = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("wings_minHeight, wings_maxHeight: " + wings_minHeight + ", " + wings_maxHeight);
    }  

    if (theControlEvent.isFrom(wingsRotationRange)) {
      wings_minRotation = theControlEvent.getController().getArrayValue(0);
      wings_maxRotation = theControlEvent.getController().getArrayValue(1);
      println("wings_minRotation, wings_maxRotation: " + wings_minRotation + ", " + wings_maxRotation);
    }  

    if (theControlEvent.isFrom(wingsShearRange)) {
      wings_minShear = PApplet.parseInt(theControlEvent.getController().getArrayValue(0));
      wings_maxShear = PApplet.parseInt(theControlEvent.getController().getArrayValue(1));
      println("wings_minShear, wings_maxShear: " + wings_minShear + ", " + wings_maxShear);
    }
  }

  public void makeSectors() {
    int sectorW = (int)(width - UI_PANEL_WIDTH - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsAcross - 1))) / this.sectorsAcross;
    int sectorH = (int)(height - (GRID_OUTER_MARGIN * 2) - (GRID_INNER_MARGIN * (this.sectorsDown - 1))) / sectorsDown;

    for (int y = 0; y < sectorsDown; y++) {
      for (int x = 0; x < sectorsAcross; x++) {
        PVector secCorner = new PVector(x*sectorW + GRID_OUTER_MARGIN + (x * GRID_INNER_MARGIN) + UI_PANEL_WIDTH, y*sectorH + GRID_OUTER_MARGIN + (y * GRID_INNER_MARGIN));
        Sector s = null;
        s = new WingSector(x, y, secCorner, sectorW, sectorH);
        if (null != s) {
          sectors[x][y] = s;
        }
      }
    }
  }
}
  public void settings() {  size(1280, 720); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "generative_ships" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
